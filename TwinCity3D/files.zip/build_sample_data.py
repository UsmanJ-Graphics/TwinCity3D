"""
build_sample_data.py

Generates data/raw/osm_sample.json -- a FALLBACK dataset used only when the
live Overpass API is unreachable (see download_data.py, Phase 22 Fallback
Mode).

This is explicitly SAMPLE / DEMO data:
  - It is shaped exactly like a real Overpass "out geom;" response so the
    rest of the pipeline (preprocess_osm.py) can't tell the difference
    structurally.
  - It is loosely modeled on the real character of the MM Alam Road /
    Gulberg III corridor described in Phase 1 (a dense commercial spine
    with quieter residential side streets and a few green pockets), but
    the individual building footprints, names, and heights are synthetic,
    not surveyed.
  - Every element carries "sample": true and the file carries a top-level
    "_meta.source": "sample_fallback" flag so nothing downstream can
    mistake it for a real OSM extract (Critical Engineering Rule #2).

Run this once to (re)generate the fallback file; download_data.py falls
back to reading it when overpass-api.de can't be reached.
"""

import json
import random
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
BBOX_PATH = REPO_ROOT / "data" / "raw" / "study_area_bbox.json"
OUT_PATH = REPO_ROOT / "data" / "raw" / "osm_sample.json"

random.seed(42)  # deterministic output -> reproducible demo


def lerp(a, b, t):
    return a + (b - a) * t


def make_rect_footprint(center_lat, center_lon, half_w_deg, half_h_deg, skew=0.0):
    """Small rectangular building footprint in lon/lat, closed ring."""
    pts = [
        (center_lon - half_w_deg, center_lat - half_h_deg),
        (center_lon + half_w_deg, center_lat - half_h_deg + skew),
        (center_lon + half_w_deg, center_lat + half_h_deg),
        (center_lon - half_w_deg, center_lat + half_h_deg - skew),
    ]
    pts.append(pts[0])
    return [{"lat": lat, "lon": lon} for lon, lat in pts]


def main():
    with open(BBOX_PATH, "r", encoding="utf-8") as f:
        bbox = json.load(f)

    lat_min, lat_max = bbox["latitude_min"], bbox["latitude_max"]
    lon_min, lon_max = bbox["longitude_min"], bbox["longitude_max"]
    lat_c = (lat_min + lat_max) / 2.0
    lon_c = (lon_min + lon_max) / 2.0

    elements = []
    next_id = 1000

    def new_id():
        nonlocal next_id
        next_id += 1
        return next_id

    # --- MM Alam Road: a north-south commercial spine roughly through the
    # bbox center, plus a couple of cross streets (Main Boulevard side).
    mm_alam_lon = lon_c + 0.0006
    road_defs = [
        # (tag highway value, name, list of (lat, lon) points)
        ("primary", "MM Alam Road",
         [(lat_min + 0.0005, mm_alam_lon), (lat_max - 0.0005, mm_alam_lon)]),
        ("secondary", "Main Boulevard",
         [(lat_c, lon_min + 0.0005), (lat_c, lon_max - 0.0005)]),
        ("residential", "Block C Street",
         [(lat_min + 0.004, lon_min + 0.001), (lat_min + 0.004, lon_max - 0.001)]),
        ("residential", "Block D Street",
         [(lat_max - 0.004, lon_min + 0.001), (lat_max - 0.004, lon_max - 0.001)]),
        ("residential", "Y-Block Link Road",
         [(lat_min + 0.001, lon_c - 0.003), (lat_max - 0.001, lon_c - 0.003)]),
    ]
    for highway_type, name, pts in road_defs:
        elements.append({
            "type": "way",
            "id": new_id(),
            "sample": True,
            "tags": {"highway": highway_type, "name": name},
            "geometry": [{"lat": lat, "lon": lon} for lat, lon in pts],
        })

    # --- Buildings along MM Alam Road: dense commercial strip, mixed
    # building:levels to drive height estimation.
    commercial_names = [
        "MM Alam Plaza", "Al-Fatah Shopping", "Cafe Aylanto Block",
        "Packages Mall Annex", "Y-Block Retail Row", "Gulberg Galleria",
        "Main Boulevard Tower", "Sozo Restaurant Building",
    ]
    n_commercial = 10
    for i in range(n_commercial):
        t = i / (n_commercial - 1)
        lat = lerp(lat_min + 0.002, lat_max - 0.002, t) + random.uniform(-0.0003, 0.0003)
        lon = mm_alam_lon + random.choice([-1, 1]) * random.uniform(0.0006, 0.0016)
        levels = random.choice([2, 3, 4, 5, 6])
        elements.append({
            "type": "way",
            "id": new_id(),
            "sample": True,
            "tags": {
                "building": random.choice(["commercial", "retail", "yes"]),
                "name": random.choice(commercial_names) + f" {i+1}",
                "building:levels": str(levels),
            },
            "geometry": make_rect_footprint(lat, lon, 0.00035, 0.00025,
                                             skew=random.uniform(-0.00005, 0.00005)),
        })

    # --- Residential buildings on the quieter side streets.
    n_residential = 14
    for i in range(n_residential):
        t = i / (n_residential - 1)
        lat = lerp(lat_min + 0.001, lat_max - 0.001, t) + random.uniform(-0.001, 0.001)
        side = random.choice([-1, 1])
        lon = lon_c + side * random.uniform(0.0025, 0.006)
        levels = random.choice([1, 1, 2, 2, 3])
        elements.append({
            "type": "way",
            "id": new_id(),
            "sample": True,
            "tags": {
                "building": "house" if levels <= 2 else "apartments",
                "building:levels": str(levels),
            },
            "geometry": make_rect_footprint(lat, lon, 0.00022, 0.0002),
        })

    # --- Green areas / roundabouts.
    green_defs = [
        ("park", "Main Boulevard Roundabout Garden", lat_c, lon_c, 0.0006, 0.0004),
        ("garden", "Y-Block Park", lat_min + 0.006, lon_min + 0.003, 0.0004, 0.0004),
        ("grass", "Block C Green Strip", lat_max - 0.003, lon_max - 0.004, 0.0005, 0.0003),
    ]
    for leisure_type, name, lat, lon, hw, hh in green_defs:
        tags = {"name": name}
        if leisure_type in ("park", "garden"):
            tags["leisure"] = leisure_type
        else:
            tags["landuse"] = leisure_type
        elements.append({
            "type": "way",
            "id": new_id(),
            "sample": True,
            "tags": tags,
            "geometry": make_rect_footprint(lat, lon, hw, hh),
        })

    # --- Facilities: school, hospital/clinic, banks, marketplace.
    facility_defs = [
        ("school", "Lahore Grammar School Gulberg", lat_min + 0.0035, lon_min + 0.0045),
        ("hospital", "Gulberg General Hospital", lat_max - 0.0025, lon_c + 0.001),
        ("clinic", "MM Alam Medical Clinic", lat_c + 0.0006, mm_alam_lon + 0.0004),
        ("bank", "Habib Bank MM Alam Branch", lat_c - 0.0008, mm_alam_lon - 0.0003),
        ("bank", "Standard Chartered Gulberg", lat_c + 0.003, mm_alam_lon + 0.0006),
        ("marketplace", "Liberty-adjacent Market", lat_min + 0.0015, lon_max - 0.0035),
    ]
    for amenity, name, lat, lon in facility_defs:
        elements.append({
            "type": "node",
            "id": new_id(),
            "sample": True,
            "lat": lat,
            "lon": lon,
            "tags": {"amenity": amenity, "name": name},
        })

    out = {
        "version": 0.6,
        "generator": "build_sample_data.py (Lahore Urban Heat Digital Twin)",
        "elements": elements,
        "_meta": {
            "source": "sample_fallback",
            "note": ("SAMPLE / DEMO data, not a live OSM extract. Generated for the Phase 1 "
                      "study area (Gulberg III / MM Alam Road corridor) to keep the pipeline "
                      "runnable offline. See docs/data_sources.md."),
        },
    }

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT_PATH, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)

    n_buildings = sum(1 for e in elements if "building" in e.get("tags", {}))
    n_roads = sum(1 for e in elements if "highway" in e.get("tags", {}))
    n_green = sum(1 for e in elements if "leisure" in e.get("tags", {}) or "landuse" in e.get("tags", {}))
    n_facilities = sum(1 for e in elements if "amenity" in e.get("tags", {}))
    print(f"[build_sample_data] Wrote {OUT_PATH}")
    print(f"[build_sample_data] buildings={n_buildings} roads={n_roads} "
          f"green_areas={n_green} facilities={n_facilities}")


if __name__ == "__main__":
    main()
